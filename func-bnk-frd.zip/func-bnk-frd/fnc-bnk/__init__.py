import logging
import azure.functions as func
import json

def main(myblob: func.InputStream):
    logging.info(f"Triggered by: {myblob.name}, Size: {myblob.length} bytes")
    blob_data = myblob.read().decode("utf-8")
    try:
        data = json.loads(blob_data)
        logging.info(f"Read data: {data}")
        if isinstance(data, dict) and data.get("is_fraud") == 1:
            logging.warning("Fraud detected! Take action here.")
    except Exception as e:
        logging.error(f"Error processing blob: {e}")
